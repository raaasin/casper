token="MTE4Nzc3Njg3MjY4MDAwOTg0OQ.GtHgYO.Cc192i1jegKqTPFWPUqusCMMTI-Lra8a8785lE"
invite="https://discord.com/oauth2/authorize?client_id=1187776872680009849&permissions=1084479765568&scope=bot"
key="AIzaSyCULdKQlMq3uNi72ozd6C1GK01hn2MbkaE"